# Personal Portfolio Website

A modern, responsive portfolio website built with React, TypeScript, and Tailwind CSS, featuring a dark theme and smooth animations.

## Features
- Modern, responsive design
- Dark theme
- Interactive project showcase
- Contact form with EmailJS integration
- Smooth page transitions and animations
- Project filtering and categorization

## Tech Stack
- React.js
- TypeScript
- Tailwind CSS
- Framer Motion
- EmailJS
- Shadcn UI

## Setup Instructions

1. Clone the repository
```bash
git clone <your-repo-url>
cd portfolio-website
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
Create a `.env` file in the root directory with the following variables:
```
VITE_EMAILJS_SERVICE_ID=your_service_id
VITE_EMAILJS_TEMPLATE_ID=your_template_id
VITE_EMAILJS_PUBLIC_KEY=your_public_key
```

4. Run the development server
```bash
npm run dev
```

5. Build for production
```bash
npm run build
```

## Deployment
The project is configured for deployment on Netlify. Simply connect your GitHub repository to Netlify and it will automatically build and deploy your site.

Remember to add the environment variables in your Netlify dashboard under Site settings > Environment variables.

## Structure
```
client/
  ├── src/
  │   ├── components/    # React components
  │   ├── lib/          # Utility functions
  │   ├── hooks/        # Custom React hooks
  │   └── App.tsx       # Main application component
  ├── index.html
  └── vite.config.ts    # Vite configuration
```

## License
MIT License

## Author
Your Name
